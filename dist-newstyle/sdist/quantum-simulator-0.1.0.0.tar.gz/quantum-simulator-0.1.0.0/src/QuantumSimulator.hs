{-# LANGUAGE OverloadedStrings #-}

module Main where

import System.Random (randomRIO)
import Graphics.Rendering.Chart.Easy
import Graphics.Rendering.Chart.Backend.Diagrams (toFile)
import Data.Colour
import Data.Colour.Names (blue, opaque)

-- Types
type Amplitude = (Double, Double)  -- Complex number (real, imag)
type Qubit = (Amplitude, Amplitude) -- (|0⟩, |1⟩) amplitudes

-- Complex number operations
add :: Amplitude -> Amplitude -> Amplitude
add (a, b) (c, d) = (a + c, b + d)

mul :: Amplitude -> Amplitude -> Amplitude
mul (a, b) (c, d) = (a*c - b*d, a*d + b*c)

magnitudeSquared :: Amplitude -> Double
magnitudeSquared (a, b) = a*a + b*b

-- Basic qubits
zeroQubit :: Qubit
zeroQubit = ((1, 0), (0, 0)) -- |0⟩

oneQubit :: Qubit
oneQubit = ((0, 0), (1, 0)) -- |1⟩

-- Quantum gates as matrices
hadamard :: [[Amplitude]]
hadamard =
  [ [(1 / sqrt 2, 0), (1 / sqrt 2, 0)],
    [(1 / sqrt 2, 0), (-1 / sqrt 2, 0)]
  ]

pauliX :: [[Amplitude]]
pauliX =
  [ [(0, 0), (1, 0)],
    [(1, 0), (0, 0)]
  ]

-- Apply gate
applyGate :: [[Amplitude]] -> Qubit -> Qubit
applyGate [[a, b], [c, d]] (q0, q1) =
  ( add (mul a q0) (mul b q1),
    add (mul c q0) (mul d q1)
  )

-- Measurement
measure :: Qubit -> IO Int
measure (a0, a1) = do
  let p0 = magnitudeSquared a0
  r <- randomRIO (0.0, 1.0)
  return $ if r < p0 then 0 else 1

-- Visualization using Chart
plotProbabilities :: Qubit -> FilePath -> IO ()
plotProbabilities (a0, a1) outFile = toFile def outFile $ do
  layout_title .= "Qubit State Probabilities"
  layout_y_axis . laxis_title .= "Probability"

  let p0 = magnitudeSquared a0
      p1 = magnitudeSquared a1

  plot $ liftEC $ do
    plot_bars_titles .= ["|0⟩", "|1⟩"]
    plot_bars_values .= addIndexes [[p0, p1]]
    plot_bars_style .= BarsClustered
    plot_bars_item_styles .= [(FillStyleSolid (opaque blue), Nothing)]

-- Main
main :: IO ()
main = do
  putStrLn "Simulating Hadamard gate on |0⟩"
  let state = applyGate hadamard zeroQubit
  result <- measure state
  putStrLn $ "Measurement result: |" ++ show result ++ "⟩"

  -- Plot probabilities
  plotProbabilities state "probabilities.png"
  putStrLn "Probability bar chart saved as probabilities.png"
